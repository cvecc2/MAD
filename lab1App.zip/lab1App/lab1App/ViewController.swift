//
//  ViewController.swift
//  lab1App
//
//  Created by Chris Vecchio on 9/10/19.
//  Copyright © 2019 Chris Vecchio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var messageOutput: UILabel!
    
    @IBOutlet weak var carImageArea: UIImageView!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        
        if sender.tag == 1{
            carImageArea.image = UIImage(named: "911")
            messageOutput.text = "You should buy a Porsche 911"
        }
        else if sender.tag == 2{
            carImageArea.image = UIImage(named: "F150")
            messageOutput.text = "You should buy a Ford F150"
        }
        else if sender.tag == 3 {
            carImageArea.image = UIImage(named: "X5")
            messageOutput.text = "You should buy a BMW X5"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

